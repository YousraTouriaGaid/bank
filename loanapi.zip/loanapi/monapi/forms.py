from django import forms
from django.forms import ModelForm
from . models import approvals
from monapi import models

class ApprovalForm(forms.Form):
    firstname = forms.CharField(max_length=15)
    lastname = forms.CharField(max_length=15)
    dependants = forms.IntegerField(default=0)
    applicantincome = forms.IntegerField(default=0)
    coapplicatincome = forms.IntegerField(default=0)
    loanamt = forms.IntegerField(default=0)
    loanterm = forms.IntegerField(default=0)
    credithistory = forms.IntegerField(default=0)
    gender = forms.CharField(max_length=15, choices=[  ('Male', 'Male'),('Female', 'Female')])
    married = forms.CharField(max_length=15, choices=[('Yes', 'Yes'),
        ('No', 'No')])
    graduatededucation = forms.CharField(max_length=15, choices=[ ('Graduate', 'Graduated'),
        ('Not_Graduate', 'Not_Graduate')])
    selfemployed = forms.CharField(max_length=15, choices=[('Yes', 'Yes'),
        ('No', 'No')])
    area = forms.CharField(max_length=15, choices=[('Rural', 'Rural'),
        ('Semiurban', 'Semiurban'),
        ('Urban', 'Urban')])