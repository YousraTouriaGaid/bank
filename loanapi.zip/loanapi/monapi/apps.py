from django.apps import AppConfig


class MonapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'monapi'
